package com.safiislam.nexvault.presentation.platform

import androidx.compose.runtime.staticCompositionLocalOf

interface SystemScreens {

    fun openAppSettings()

    fun openAllFilesAccess()

    fun openBatteryOptimization()
}

val LocalSystemScreens = staticCompositionLocalOf<SystemScreens> {
    error("SystemScreens is not provided")
}
