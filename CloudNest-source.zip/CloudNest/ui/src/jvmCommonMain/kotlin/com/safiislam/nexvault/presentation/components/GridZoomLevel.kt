package com.safiislam.nexvault.presentation.components

import com.safiislam.nexvault.domain.model.ViewMode

data class GridZoomLevel(val viewMode: ViewMode, val gridSize: Int)
