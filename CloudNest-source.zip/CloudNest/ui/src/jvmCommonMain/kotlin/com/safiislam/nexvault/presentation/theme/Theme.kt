package com.safiislam.nexvault.presentation.theme

import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.safiislam.nexvault.domain.model.AccentColor

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun NexVaultTheme(
    darkTheme: Boolean = systemDarkTheme(),
    dynamicColor: Boolean = false,
    amoled: Boolean = false,
    accent: AccentColor = AccentColor.VIOLET,
    content: @Composable () -> Unit
) {
    val base = platformColorScheme(darkTheme, dynamicColor)
        ?: if (darkTheme) NexVaultDarkColorScheme else NexVaultLightColorScheme
    val branded = if (dynamicColor) base else base.withAccent(accent, darkTheme)
    val colorScheme = if (darkTheme && amoled) {
        branded.copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceContainerLowest = Color.Black,
            surfaceContainerLow = Color(0xFF07080D),
            surfaceContainer = Color(0xFF0D0F16),
            surfaceContainerHigh = Color(0xFF13161F),
            surfaceContainerHighest = Color(0xFF1A1E29)
        )
    } else branded

    PlatformThemeSideEffects(darkTheme)

    MaterialExpressiveTheme(
        colorScheme = colorScheme,
        motionScheme = MotionScheme.expressive(),
        typography = NexVaultTypography,
        shapes = NexVaultShapes,
        content = content
    )
}
