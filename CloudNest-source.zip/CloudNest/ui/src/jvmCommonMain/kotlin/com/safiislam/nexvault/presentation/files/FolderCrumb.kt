package com.safiislam.nexvault.presentation.files

import com.safiislam.nexvault.presentation.common.UiText

/** A null id is the root. */
data class FolderCrumb(
    val id: String?,
    val name: UiText
)
