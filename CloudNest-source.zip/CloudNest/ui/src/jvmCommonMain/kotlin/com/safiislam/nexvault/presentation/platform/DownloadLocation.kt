package com.safiislam.nexvault.presentation.platform

import androidx.compose.runtime.staticCompositionLocalOf

val LocalDownloadLocationConfigurable = staticCompositionLocalOf { false }
