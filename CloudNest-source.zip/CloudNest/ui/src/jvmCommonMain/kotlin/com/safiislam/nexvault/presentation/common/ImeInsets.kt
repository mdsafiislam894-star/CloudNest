package com.safiislam.nexvault.presentation.common

import androidx.compose.runtime.Composable

@Composable
expect fun imeTargetBottomInset(): Int
