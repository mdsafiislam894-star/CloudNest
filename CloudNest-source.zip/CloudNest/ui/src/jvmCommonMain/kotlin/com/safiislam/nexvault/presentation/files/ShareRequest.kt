package com.safiislam.nexvault.presentation.files

data class ShareRequest(val paths: List<String>, val mimeType: String)
