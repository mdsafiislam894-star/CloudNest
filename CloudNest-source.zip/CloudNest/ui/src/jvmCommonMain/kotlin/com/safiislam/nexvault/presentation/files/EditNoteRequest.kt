package com.safiislam.nexvault.presentation.files

data class EditNoteRequest(val fileId: String, val title: String)
