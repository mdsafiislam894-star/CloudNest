package com.safiislam.nexvault.presentation.components

internal data class QuickFolderChip(
    val label: String,
    val path: String,
    val isHome: Boolean = false
)
