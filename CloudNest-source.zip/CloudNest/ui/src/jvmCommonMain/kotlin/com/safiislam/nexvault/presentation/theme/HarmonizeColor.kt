package com.safiislam.nexvault.presentation.theme

internal expect fun harmonizeColor(argb: Int, primaryArgb: Int): Int
