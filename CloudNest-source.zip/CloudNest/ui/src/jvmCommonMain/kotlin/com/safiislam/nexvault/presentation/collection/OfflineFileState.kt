package com.safiislam.nexvault.presentation.collection

enum class OfflineFileState {
    ON_DEVICE,
    DOWNLOADING,
    MISSING
}
