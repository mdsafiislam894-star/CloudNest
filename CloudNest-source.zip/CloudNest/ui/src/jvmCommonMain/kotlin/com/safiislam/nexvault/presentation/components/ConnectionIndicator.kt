package com.safiislam.nexvault.presentation.components

enum class ConnectionIndicator { CONNECTED, WORKING, OFFLINE }
