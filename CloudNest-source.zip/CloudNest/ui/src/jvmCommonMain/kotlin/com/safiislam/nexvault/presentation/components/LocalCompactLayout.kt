package com.safiislam.nexvault.presentation.components

import androidx.compose.runtime.compositionLocalOf

val LocalCompactLayout = compositionLocalOf { false }
