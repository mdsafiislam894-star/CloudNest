package com.safiislam.nexvault.presentation.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import org.jetbrains.compose.resources.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.safiislam.nexvault.resources.Res
import com.safiislam.nexvault.resources.info_added
import com.safiislam.nexvault.resources.info_backup
import com.safiislam.nexvault.resources.info_backup_done
import com.safiislam.nexvault.resources.info_backup_failed
import com.safiislam.nexvault.resources.info_backup_none
import com.safiislam.nexvault.resources.info_backup_queued
import com.safiislam.nexvault.resources.info_backup_uploading
import com.safiislam.nexvault.resources.info_created
import com.safiislam.nexvault.resources.info_duration
import com.safiislam.nexvault.resources.info_encrypted
import com.safiislam.nexvault.resources.info_extension
import com.safiislam.nexvault.resources.info_local_copy
import com.safiislam.nexvault.resources.info_modified
import com.safiislam.nexvault.resources.info_no
import com.safiislam.nexvault.resources.info_path
import com.safiislam.nexvault.resources.info_resolution
import com.safiislam.nexvault.resources.info_sha256
import com.safiislam.nexvault.resources.info_size
import com.safiislam.nexvault.resources.info_type
import com.safiislam.nexvault.resources.info_yes
import com.safiislam.nexvault.domain.model.BackupState
import com.safiislam.nexvault.domain.model.DriveFile
import com.safiislam.nexvault.presentation.common.Formatters
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileInfoSheet(
    file: DriveFile,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 8.dp)
        ) {
            Text(
                text = file.name,
                style = MaterialTheme.typography.titleLarge
            )
            Spacer(Modifier.height(16.dp))

            InfoRow(stringResource(Res.string.info_size), Formatters.bytes(file.sizeBytes))
            InfoRow(stringResource(Res.string.info_type), file.mimeType)
            file.extension.takeIf { it.isNotEmpty() }?.let {
                InfoRow(stringResource(Res.string.info_extension), it.uppercase(Locale.ROOT))
            }
            if (file.width != null && file.height != null) {
                InfoRow(stringResource(Res.string.info_resolution), "${file.width} × ${file.height}")
            }
            file.durationMs?.let {
                InfoRow(
                    stringResource(Res.string.info_duration),
                    Formatters.duration(it)
                )
            }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))

            InfoRow(stringResource(Res.string.info_created), Formatters.dateTime(file.createdAt))
            InfoRow(stringResource(Res.string.info_modified), Formatters.dateTime(file.modifiedAt))
            InfoRow(stringResource(Res.string.info_added), Formatters.dateTime(file.addedAt))

            HorizontalDivider(Modifier.padding(vertical = 12.dp))

            InfoRow(
                stringResource(Res.string.info_backup),
                when (file.backupState) {
                    BackupState.BACKED_UP -> stringResource(Res.string.info_backup_done)
                    BackupState.UPLOADING -> stringResource(Res.string.info_backup_uploading)
                    BackupState.QUEUED -> stringResource(Res.string.info_backup_queued)
                    BackupState.FAILED -> stringResource(Res.string.info_backup_failed)
                    BackupState.NONE -> stringResource(Res.string.info_backup_none)
                }
            )
            InfoRow(
                stringResource(Res.string.info_local_copy),
                stringResource(if (file.hasLocalCopy) Res.string.info_yes else Res.string.info_no)
            )
            InfoRow(
                stringResource(Res.string.info_encrypted),
                stringResource(if (file.isEncrypted) Res.string.info_yes else Res.string.info_no)
            )
            file.localPath?.let {
                InfoRow(
                    stringResource(Res.string.info_path),
                    it,
                    monospace = true
                )
            }
            file.contentHash?.let {
                InfoRow(
                    stringResource(Res.string.info_sha256),
                    it,
                    monospace = true
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String, monospace: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .padding(end = 16.dp)
                .weight(0.35f)
        )
        Text(
            text = value,
            style = if (monospace) {
                MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
            } else {
                MaterialTheme.typography.bodyMedium
            },
            modifier = Modifier.weight(0.65f)
        )
    }
}
