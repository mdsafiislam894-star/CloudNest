package com.safiislam.nexvault.presentation.components

data class LocalFolderItem(
    val name: String,
    val path: String
)
