package com.safiislam.nexvault.presentation.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.safiislam.nexvault.core.permissions.AppPermission
import com.safiislam.nexvault.core.permissions.PermissionChecker
import com.safiislam.nexvault.presentation.platform.LocalPermissionRequester
import com.safiislam.nexvault.presentation.platform.LocalSystemScreens
import com.safiislam.nexvault.resources.Res
import com.safiislam.nexvault.resources.permission_not_allowed
import com.safiislam.nexvault.resources.permissions_allowed
import com.safiislam.nexvault.resources.permissions_not_allowed
import com.safiislam.nexvault.resources.permissions_not_allowed_optional
import org.jetbrains.compose.resources.stringResource

/**
 * Falls back to the app's settings page once the system stops showing the dialog, the only way back
 * from a permanent denial.
 */
@Composable
fun PermissionsSection(permissionChecker: PermissionChecker) {
    val lifecycleOwner = LocalLifecycleOwner.current
    var statuses by remember { mutableStateOf(permissionChecker.statuses()) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                statuses = permissionChecker.statuses()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val permissionRequester = LocalPermissionRequester.current
    val systemScreens = LocalSystemScreens.current

    SettingsGroup {
        AppPermission.entries.forEach { permission ->
            val granted = statuses[permission] == true
            add(visible = permissionChecker.isRequestable(permission)) {
                PermissionRow(
                    permission = permission,
                    granted = granted,
                    onClick = {
                        when {
                            granted -> systemScreens.openAppSettings()
                            permission == AppPermission.UNRESTRICTED_BATTERY ->
                                systemScreens.openBatteryOptimization()

                            permission.isSpecialAccess -> systemScreens.openAllFilesAccess()
                            else -> permissionRequester.request(listOf(permission)) {
                                statuses = permissionChecker.statuses()
                            }
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun PermissionRow(
    permission: AppPermission,
    granted: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(stringResource(permission.titleRes), style = MaterialTheme.typography.bodyLarge)
            Text(
                text = if (granted) {
                    stringResource(Res.string.permissions_allowed)
                } else if (permission.critical) {
                    stringResource(
                        Res.string.permission_not_allowed,
                        stringResource(permission.rationaleRes)
                    )
                } else {
                    stringResource(Res.string.permissions_not_allowed_optional)
                },
                style = MaterialTheme.typography.bodySmall,
                color = if (granted || !permission.critical) {
                    MaterialTheme.colorScheme.onSurfaceVariant
                } else {
                    MaterialTheme.colorScheme.error
                }
            )
        }
        Spacer(Modifier.width(16.dp))
        Icon(
            imageVector = if (granted) Icons.Filled.CheckCircle else Icons.Outlined.Cancel,
            contentDescription = if (granted) stringResource(Res.string.permissions_allowed) else stringResource(
                Res.string.permissions_not_allowed
            ),
            modifier = Modifier.size(22.dp),
            tint = when {
                granted -> MaterialTheme.colorScheme.primary
                permission.critical -> MaterialTheme.colorScheme.error
                else -> MaterialTheme.colorScheme.outline
            }
        )
    }
}
