package com.safiislam.nexvault.presentation.files

data class RenameTarget(
    val id: String,
    val name: String,
    val isFolder: Boolean
)
