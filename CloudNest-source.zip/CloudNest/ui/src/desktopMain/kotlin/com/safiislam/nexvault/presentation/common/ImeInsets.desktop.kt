package com.safiislam.nexvault.presentation.common

import androidx.compose.runtime.Composable

@Composable
actual fun imeTargetBottomInset(): Int = 0
