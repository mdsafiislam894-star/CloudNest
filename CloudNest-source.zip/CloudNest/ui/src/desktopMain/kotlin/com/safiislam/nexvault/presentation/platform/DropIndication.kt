package com.safiislam.nexvault.presentation.platform

internal enum class DropIndication {
    NONE,
    FILES,
    FOLDERS
}
