package com.safiislam.nexvault.desktop.media.player

internal data class VlcTrack(
    val id: Int,
    val label: String,
    val language: String,
    val selected: Boolean
)
