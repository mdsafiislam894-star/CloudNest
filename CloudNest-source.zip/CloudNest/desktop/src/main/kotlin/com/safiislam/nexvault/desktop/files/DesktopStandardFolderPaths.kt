package com.safiislam.nexvault.desktop.files

import com.safiislam.nexvault.presentation.platform.StandardFolderPaths

class DesktopStandardFolderPaths : StandardFolderPaths {

    override val camera: String? = null

    override val pictures: String? = null

    override val movies: String? = null
}
