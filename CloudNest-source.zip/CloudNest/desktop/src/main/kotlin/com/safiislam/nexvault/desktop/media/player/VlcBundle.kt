package com.safiislam.nexvault.desktop.media.player

import java.io.File

internal class VlcBundle(val libraries: File, val plugins: File?)
