package com.safiislam.nexvault.core.transfer

internal class TransferControlException(val paused: Boolean) : Exception()
