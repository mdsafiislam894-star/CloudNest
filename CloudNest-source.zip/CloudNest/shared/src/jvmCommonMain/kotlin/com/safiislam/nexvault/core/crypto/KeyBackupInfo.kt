package com.safiislam.nexvault.core.crypto

data class KeyBackupInfo(val hint: String?)
