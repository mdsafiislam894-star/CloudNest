package com.safiislam.nexvault.data.repository

internal enum class ReconcileResult { INSERTED, UPDATED, UNCHANGED }
