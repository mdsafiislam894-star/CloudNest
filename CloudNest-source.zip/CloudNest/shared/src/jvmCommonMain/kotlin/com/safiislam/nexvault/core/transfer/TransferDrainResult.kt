package com.safiislam.nexvault.core.transfer

enum class TransferDrainResult {
    COMPLETED,
    INTERRUPTED
}
