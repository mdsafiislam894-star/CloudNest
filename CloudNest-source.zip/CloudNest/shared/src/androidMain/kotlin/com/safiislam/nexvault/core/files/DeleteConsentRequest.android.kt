package com.safiislam.nexvault.core.files

import android.content.IntentSender

actual typealias DeleteConsentRequest = IntentSender
