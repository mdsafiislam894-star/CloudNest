package com.safiislam.nexvault.core.network

enum class NetworkStatus {
    UNAVAILABLE,
    METERED,
    UNMETERED
}
