package com.safiislam.nexvault.core.files

expect class DeleteConsentRequest
