package com.safiislam.nexvault.data.repository

interface LocalDataWiper {

    suspend fun wipe()
}
