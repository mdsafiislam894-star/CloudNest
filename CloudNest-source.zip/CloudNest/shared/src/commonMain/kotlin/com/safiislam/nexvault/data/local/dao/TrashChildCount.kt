package com.safiislam.nexvault.data.local.dao

data class TrashChildCount(
    val parentId: String,
    val childCount: Int
)
