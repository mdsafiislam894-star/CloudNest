package com.safiislam.nexvault.domain.model

enum class BackupHold {
    CHARGER,
    WIFI
}
