package com.safiislam.nexvault.domain.model

enum class TransferSection {
    ACTIVE,
    PAUSED,
    FAILED,
    COMPLETED
}
