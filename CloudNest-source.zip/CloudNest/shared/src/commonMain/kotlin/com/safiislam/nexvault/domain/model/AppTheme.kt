package com.safiislam.nexvault.domain.model

enum class AppTheme {
    LIGHT,
    DARK,
    SYSTEM,
    AMOLED
}
