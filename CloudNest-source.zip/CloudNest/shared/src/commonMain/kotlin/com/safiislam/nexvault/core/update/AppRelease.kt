package com.safiislam.nexvault.core.update

data class AppRelease(
    val version: String,
    val notes: String,
    val pageUrl: String
)
