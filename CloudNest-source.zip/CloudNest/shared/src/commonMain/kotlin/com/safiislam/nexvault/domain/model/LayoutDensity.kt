package com.safiislam.nexvault.domain.model

enum class LayoutDensity {
    COMPACT,
    COMFORTABLE
}
