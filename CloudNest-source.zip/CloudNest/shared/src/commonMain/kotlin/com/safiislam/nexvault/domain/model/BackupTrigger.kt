package com.safiislam.nexvault.domain.model

enum class BackupTrigger {
    MANUAL,
    SCHEDULED,
    AUTOMATIC
}
