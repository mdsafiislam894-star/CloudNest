package com.safiislam.nexvault.core.crypto

object CryptoKeys {
    const val CONTENT = "content"
    const val THUMBNAIL = "thumbnail"
    const val CACHE = "cache"
    const val TDLIB_DATABASE = "tdlib_db"
}
