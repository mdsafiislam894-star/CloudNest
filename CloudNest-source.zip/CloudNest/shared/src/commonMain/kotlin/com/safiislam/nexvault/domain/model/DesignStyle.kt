package com.safiislam.nexvault.domain.model

/**
 * Whole-app look, independent of light/dark mode and accent colour.
 * COLORFUL is the default CloudNest look; IOS_GLASS restyles everything like an iPhone;
 * WARM is a warm orange-and-cream editorial look.
 */
enum class DesignStyle {
    COLORFUL,
    IOS_GLASS,
    WARM
}
