package com.safiislam.nexvault.data.local.dao

data class FolderOwner(
    val folderId: String,
    val chatId: Long?
)
