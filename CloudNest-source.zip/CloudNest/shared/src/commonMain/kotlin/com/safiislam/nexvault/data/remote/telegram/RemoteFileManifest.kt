package com.safiislam.nexvault.data.remote.telegram

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Keys are shortened to fit the caption limit; the captions alone can rebuild the local database.
 */
@Serializable
data class RemoteFileManifest(
    @SerialName("v") val version: Int = VERSION,
    @SerialName("id") val fileId: String,
    @SerialName("n") val name: String,
    @SerialName("p") val folderPath: String,
    @SerialName("fid") val folderId: String? = null,
    @SerialName("m") val mimeType: String,
    @SerialName("s") val sizeBytes: Long,
    @SerialName("h") val contentHash: String? = null,
    @SerialName("hd") val hidden: Boolean = false,
    @SerialName("ar") val archived: Boolean = false,
    @SerialName("fv") val favorite: Boolean = false,
    @SerialName("tr") val trashedAt: Long? = null,
    @SerialName("e") val encrypted: Boolean = false,
    @SerialName("ct") val createdAt: Long,
    @SerialName("mt") val modifiedAt: Long,
    @SerialName("w") val width: Int? = null,
    @SerialName("ht") val height: Int? = null,
    @SerialName("d") val durationMs: Long? = null,
    @SerialName("pc") val partCount: Int = 0,
    @SerialName("pi") val partIndex: Int = 0,
    @SerialName("po") val partOffset: Long = 0,
    @SerialName("ps") val partSize: Long = 0,
    @SerialName("icon") val iconFileId: String? = null
) {
    val isPart: Boolean get() = partCount > 1

    companion object {
        const val VERSION = 1
        const val PART_VERSION = 2
    }
}
