package com.safiislam.nexvault.core.update

object AppLinks {
    /** Original open-source project NexVault is derived from (Apache License 2.0). */
    const val UPSTREAM_REPOSITORY = "https://github.com/Mahmud0808/TeleDrive"
    const val CREATOR_NAME = "Md. Safi Islam"
}
