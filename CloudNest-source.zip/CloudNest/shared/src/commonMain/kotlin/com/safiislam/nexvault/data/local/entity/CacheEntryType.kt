package com.safiislam.nexvault.data.local.entity

enum class CacheEntryType {
    PREVIEW,
    STREAM,
    TEMP
}
