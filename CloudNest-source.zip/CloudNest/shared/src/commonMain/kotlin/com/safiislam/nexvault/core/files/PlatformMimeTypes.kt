package com.safiislam.nexvault.core.files

internal expect fun platformMimeTypeFromExtension(extension: String): String?
