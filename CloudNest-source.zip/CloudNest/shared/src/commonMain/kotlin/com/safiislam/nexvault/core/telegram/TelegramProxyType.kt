package com.safiislam.nexvault.core.telegram

enum class TelegramProxyType {
    SOCKS5,
    MTPROTO,
    HTTP
}
