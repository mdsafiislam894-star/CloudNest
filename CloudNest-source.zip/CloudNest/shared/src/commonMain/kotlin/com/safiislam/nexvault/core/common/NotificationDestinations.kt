package com.safiislam.nexvault.core.common

object NotificationDestinations {
    const val TRANSFERS = "transfers"
    const val FILES = "files"
    const val NOTE = "note"
    const val UPDATE = "update"
}
