package com.safiislam.nexvault.domain.model

/** User-selectable accent applied on top of the NexVault brand scheme. */
enum class AccentColor {
    VIOLET,
    AQUA,
    ROSE,
    AMBER,
    EMERALD,
    SKY
}
