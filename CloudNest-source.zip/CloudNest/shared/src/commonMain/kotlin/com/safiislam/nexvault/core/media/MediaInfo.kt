package com.safiislam.nexvault.core.media

data class MediaInfo(
    val width: Int?,
    val height: Int?,
    val durationMs: Long?
)
