package com.safiislam.nexvault.core.publish

interface PublishScheduler {

    fun kick()
}
