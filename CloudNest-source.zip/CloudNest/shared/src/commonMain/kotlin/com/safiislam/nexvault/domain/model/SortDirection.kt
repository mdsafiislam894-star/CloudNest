package com.safiislam.nexvault.domain.model

enum class SortDirection {
    ASCENDING,
    DESCENDING
}
