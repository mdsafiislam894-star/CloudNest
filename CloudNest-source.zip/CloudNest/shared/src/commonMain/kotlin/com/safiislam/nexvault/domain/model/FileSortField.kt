package com.safiislam.nexvault.domain.model

enum class FileSortField {
    NAME,
    SIZE,
    DATE_MODIFIED,
    DATE_ADDED,
    TYPE,
    BACKUP_STATUS
}
