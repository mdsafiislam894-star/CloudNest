package com.safiislam.nexvault.domain.model

enum class ViewMode {
    GRID,
    LIST
}
