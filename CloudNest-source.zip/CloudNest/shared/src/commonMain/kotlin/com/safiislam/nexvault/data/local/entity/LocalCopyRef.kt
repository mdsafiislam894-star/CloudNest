package com.safiislam.nexvault.data.local.entity

data class LocalCopyRef(
    val id: String,
    val localPath: String
)
