package com.safiislam.nexvault.core.media

import java.io.File

internal actual fun platformApkIconBytes(file: File): ByteArray? = null
