package com.safiislam.nexvault.core.files

actual class DeleteConsentRequest
